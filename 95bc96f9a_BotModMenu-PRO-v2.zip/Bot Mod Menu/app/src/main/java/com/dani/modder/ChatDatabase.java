package com.dani.modder;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================
 *  DATABASE BOT — SEMUA RIWAYAT PERCAKAPAN DISIMPAN DI
 *  1 FILE: database.json (di folder internal aplikasi).
 *  Pake org.json bawaan Android, tanpa library luar.
 * ============================================================
 */
public class ChatDatabase {

    public static class Msg {
        public String role, content;
        public long time;
        public Msg(String role, String content, long time) {
            this.role = role; this.content = content; this.time = time;
        }
    }

    public static class Conv {
        public String id, title;
        public long updated;
        public ArrayList<Msg> messages = new ArrayList<>();
    }

    private final File file;
    private final ArrayList<Conv> conversations = new ArrayList<>();

    public ChatDatabase(Context ctx) {
        file = new File(ctx.getFilesDir(), "database.json");
        load();
    }

    // ================= LOAD / SAVE =================

    public synchronized void load() {
        conversations.clear();
        try {
            if (!file.exists()) return;
            String json = readAll(new FileInputStream(file));
            if (json.trim().isEmpty()) return;
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Conv c = new Conv();
                c.id = o.optString("id");
                c.title = o.optString("title", "Chat Baru");
                c.updated = o.optLong("updated");
                JSONArray msgs = o.optJSONArray("messages");
                if (msgs != null) {
                    for (int j = 0; j < msgs.length(); j++) {
                        JSONObject m = msgs.getJSONObject(j);
                        c.messages.add(new Msg(m.optString("role"), m.optString("content"), m.optLong("time")));
                    }
                }
                conversations.add(c);
            }
        } catch (Exception ignored) {}
    }

    public synchronized void save() {
        try {
            JSONArray arr = new JSONArray();
            for (Conv c : conversations) {
                JSONObject o = new JSONObject();
                o.put("id", c.id);
                o.put("title", c.title);
                o.put("updated", c.updated);
                JSONArray msgs = new JSONArray();
                for (Msg m : c.messages) {
                    JSONObject mo = new JSONObject();
                    mo.put("role", m.role);
                    mo.put("content", m.content);
                    mo.put("time", m.time);
                    msgs.put(mo);
                }
                o.put("messages", msgs);
                arr.put(o);
            }
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(arr.toString().getBytes(Charset.forName("UTF-8")));
            fos.close();
        } catch (Exception ignored) {}
    }

    // ================= CRUD =================

    public ArrayList<Conv> list() { return conversations; }

    public Conv get(String id) {
        if (id == null) return null;
        for (Conv c : conversations) if (c.id.equals(id)) return c;
        return null;
    }

    public Conv newConversation() {
        Conv c = new Conv();
        c.id = Long.toString(System.currentTimeMillis(), 36)
                + Integer.toString((int) (Math.random() * 0xFFFFFF), 36);
        c.title = "Chat Baru";
        c.updated = System.currentTimeMillis();
        conversations.add(0, c);
        save();
        return c;
    }

    public void delete(String id) {
        for (int i = 0; i < conversations.size(); i++) {
            if (conversations.get(i).id.equals(id)) {
                conversations.remove(i);
                break;
            }
        }
        save();
    }

    /** chat terakhir, atau bikin baru kalau belum ada */
    public Conv lastOrCreate() {
        if (!conversations.isEmpty()) {
            Conv last = conversations.get(0);
            for (Conv c : conversations) if (c.updated > last.updated) last = c;
            return last;
        }
        return newConversation();
    }

    public void addMessage(Conv c, String role, String content) {
        c.messages.add(new Msg(role, content, System.currentTimeMillis()));
        c.updated = System.currentTimeMillis();
        if ("user".equals(role) && "Chat Baru".equals(c.title))
            c.title = content.length() > 30 ? content.substring(0, 30) : content;
        save();
    }

    public List<BotBrain.Msg> historyOf(Conv c) {
        List<BotBrain.Msg> h = new ArrayList<>();
        for (Msg m : c.messages) h.add(new BotBrain.Msg(m.role, m.content));
        return h;
    }

    // ================= UTIL =================

    private static String readAll(FileInputStream fis) throws Exception {
        StringBuilder sb = new StringBuilder();
        byte[] buf = new byte[8192];
        int len;
        while ((len = fis.read(buf)) != -1) sb.append(new String(buf, 0, len, Charset.forName("UTF-8")));
        fis.close();
        return sb.toString();
    }
}
