package com.dani.modder;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ============================================================
 *  OTAK "BOT MOD MENU" PRO - 1 FILE INI = DATABASE PENGETAHUAN
 *  Intent chat + template hook (return/void/field/update) +
 *  ensiklopedia modding (il2cpp, dump, GG, Frida, hex patch, dll).
 *  100% rule-based, TANPA API / internet.
 * ============================================================
 */
public class BotBrain {

    public static class Msg {
        public String role, content;
        public Msg(String role, String content) { this.role = role; this.content = content; }
    }

    // ================= PATTERNS =================
    private static final Pattern TYPE_NAME = Pattern.compile(
            "(bool|int|integer|float|double|string|void)\\s+([A-Za-z_][A-Za-z0-9_]*)", Pattern.CASE_INSENSITIVE);
    private static final Pattern FIELD_HOOK = Pattern.compile(
            "field\\s+(bool|int|integer|float|double|string|long|byte)\\s+([A-Za-z_][A-Za-z0-9_]*)", Pattern.CASE_INSENSITIVE);
    private static final Pattern UPDATE_HOOK = Pattern.compile(
            "hook\\s+update\\s+([A-Za-z_][A-Za-z0-9_]*)", Pattern.CASE_INSENSITIVE);
    private static final Pattern OFFSET = Pattern.compile("0x[0-9A-Fa-f]+");
    private static final Pattern CASE_NUM = Pattern.compile("case (\\d+):");
    private static final Pattern GREETING = Pattern.compile(
            "^(halo+|hallo+|hai+|hi+|hello+|hey|woi|oi|bro)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern THANKS = Pattern.compile(
            "^(makasih|makasi|thanks|thank|thx|ty|tengkyu)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern HELP_CMD = Pattern.compile("^!?(help|bantuan|fitur|perintah)$", Pattern.CASE_INSENSITIVE);
    private static final Pattern WHO = Pattern.compile("siapa kamu|kamu siapa|kamu apa|apa ini|kenalan");

    private static final Pattern NO_UPDATE = Pattern.compile(
            "tanpa\\s+update|without\\s+update|no\\s+update|tanpa\\s+old", Pattern.CASE_INSENSITIVE);

    /** ================= PINTU UTAMA BOT ================= */
    public static String reply(String message, List<Msg> history) {
        String msg = message == null ? "" : message.trim();
        if (msg.isEmpty()) return "Ketik sesuatu bro \uD83D\uDE05";

        // ---------- INTENTS DASAR ----------
        if (HELP_CMD.matcher(msg).matches()) return helpText();
        if (WHO.matcher(msg.toLowerCase()).find()) return whoText();
        if (THANKS.matcher(msg).matches()) return "Sama-sama bro! \uD83D\uDD25 Semoga mod-nya work.";
        if (msg.toLowerCase().startsWith("!clear") || msg.toLowerCase().startsWith("!bersih"))
            return "Buat hapus chat: buka \u2630 Riwayat, tekan lama percakapannya buat hapus \uD83D\uDC81";
        if (GREETING.matcher(msg).matches() && msg.length() < 25)
            return "Halo bro! \uD83D\uDD25 Aku *Bot Mod Menu PRO* - generator hook + konsultan modding. Ketik !help buat liat semua kemampuanku.";

        // ---------- TROUBLESHOOTING (prioritas: keluhan error/crash dulu) ----------
        String low = msg.toLowerCase();
        if (low.contains("error") || low.contains("crash") || low.contains("force close")
                || low.contains("gak work") || low.contains("ga work") || low.contains("gak jalan")
                || low.contains("ngehang") || low.contains("restart sendiri"))
            return troubleshoot(msg);

        // ---------- ENSIKLOPEDIA / KNOWLEDGE ----------
        String topic = knowledge(msg);
        if (topic != null) return topic;

        // ---------- HOOK GENERATOR ----------
        List<HookReq> hooks = parseHooks(msg);
        if (!hooks.isEmpty()) {
            int num = startNumber(history);
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < hooks.size(); i++) {
                HookReq h = hooks.get(i);
                if (i > 0) out.append("\n\n---\n\n");
                out.append(hookAnswer(h, num));
                num++;
            }
            return out.toString();
        }

        // ---------- FALLBACK ----------
        return "Hmm, aku belum punya jawaban pasti buat itu bro \uD83E\uDD14\n\n"
                + "Tapi aku jago soal ini:\n"
                + "1. *Hook*: \"buat hook bool IsGodMode offset 0x1A2B3C\"\n"
                + "2. *Hook field*: \"buat hook field float Health offset 0x44\"\n"
                + "3. *Il2Cpp / dump*: \"cara dump il2cpp\"\n"
                + "4. *Game Guardian*: \"script game guardian\"\n"
                + "5. *Frida / Python / hex patch* - tanya aja langsung\n\n"
                + "Ketik !help buat semua topik.";
    }

    // ================= HELP / WHO =================
    private static String helpText() {
        return "*BOT MOD MENU - PRO MODE* \uD83D\uDD25\n\n"
                + "*1. GENERATOR HOOK* (semua siap copy):\n"
                + "- *buat hook bool IsGodMode offset 0x1A2B3C* - return-value hook\n"
                + "- int / float / double / string - sama, tinggal ganti type\n"
                + "- *buat hook void NoDeath offset 0x3F5A* - ON = fungsi di-skip\n"
                + "- *... tanpa update* - fungsi asli dimatiikan total (tanpa old_)\n"
                + "- *buat hook update Money offset 0x99* - old_ tetap jalan, siap ditambah logic\n"
                + "- *buat hook field float Health offset 0x44* - patch field langsung di address\n"
                + "- Bisa beberapa hook sekaligus: \"... dan hook float Damage offset 0x55\"\n\n"
                + "*2. ENSIKLOPEDIA MODDING* - tanya langsung:\n"
                + "- *apa itu il2cpp* / *cara dump il2cpp* / *cara cari offset*\n"
                + "- *script game guardian* (Lua) / *frida* / *script python*\n"
                + "- *hex patch* / *apa itu NOP* / *obfuscate buat apa*\n"
                + "- *speed hack* / *hook static get_Instance*\n"
                + "- *ida / ghidra* buat mulai reverse\n\n"
                + "*3. TROUBLESHOOTING*: ceritain error/crash-nya (\"mod gue crash saat inject\") dan aku kasih checklist solusinya.";
    }

    private static String whoText() {
        return "Aku *Bot Mod Menu PRO* \uD83D\uDD25 - bot generator kode hook + ensiklopedia dunia modding: "
                + "C++ mod menu, il2cpp dumping, Game Guardian, Frida, Python, hex patch, reverse engineering. "
                + "Semua offline, tanpa API. Ketik !help buat liat semua kemampuanku.";
    }

    // ================= ENSIKLOPEDIA =================
    private static String knowledge(String msg) {
        String low = msg.toLowerCase();

        if (low.contains("il2cpp") && (low.contains("apa") || low.contains("itu") || low.contains("kenapa") || low.contains("maksud")))
            return "Il2Cpp = sistem Unity yang meng-compile C# game jadi C++ native (libil2cpp.so) + metadata (global-metadata.dat).\n\n"
                    + "Artinya buat modder:\n"
                    + "1. Gak ada lagi C# gampang dibaca - kode jadi binary native\n"
                    + "2. Nama class/method disimpan di *global-metadata.dat*\n"
                    + "3. Buat nemu offset fungsi, kita *dump* metadata itu\n\n"
                    + "Tools utamanya: *Il2CppDumper* (termasuk versi PRO \uD83D\uDE0E). Hasil dump = dump.cs (semua class/method) + script.json (offset).";

        if ((low.contains("cara") || low.contains("gimana") || low.contains("how")) && low.contains("dump"))
            return "*CARA DUMP IL2CPP* \uD83D\uDD25\n\n"
                    + "1. Ambil *libil2cpp.so* (arm64 biasanya di lib/arm64-v8a) + *global-metadata.dat* (assets/bin/Data/Managed/Metadata/)\n"
                    + "2. Buka Il2CppDumper, pilih 2 file itu\n"
                    + "3. Kalau error \"magic / metadata gak valid\" - metadata di-encrypt game. Pakai *Il2CppDumper PRO* fitur auto-decrypt (XOR/ADD/reversed)\n"
                    + "4. Hasil: *dump.cs* (list class & method) + *script.json* (offset untuk IDA/Ghidra)\n\n"
                    + "Offset method di dump.cs = jarak dari base libil2cpp.so. Contoh: get_Id offset 0x1D3654C artinya base + 0x1D3654C.";

        if (low.contains("dump.cs") || (low.contains("script") && low.contains("json")))
            return "*BACA HASIL DUMP*\n\n"
                    + "*dump.cs* - cari class/method yang mau dimod:\n"
                    + "```cpp\n// Namespace: JacatGames.Platformer\npublic class UserCharacterSkin\n{\n    public static void GiveSkin(int id) { } // Offset: 0x1D78B10\n    public int get_Id() { } // Offset: 0x1D3654C\n}\n```\n"
                    + "Yang dipakai buat hook: nama method + *Offset*-nya.\n\n"
                    + "*script.json* - di-load ke IDA/Ghidra biar nama fungsi otomatis kelihatan pas reversing.";

        if ((low.contains("cari") || low.contains("nemuin") || low.contains("manual")) && low.contains("offset"))
            return "*CARI OFFSET MANUAL (tanpa dump)* \uD83D\uDD0D\n\n"
                    + "1. Buka *Game Guardian*, search nilai yang mau dimod (misal HP: 9999)\n"
                    + "2. Ubah nilai in-game, search lagi sampai sisa 1 address (contoh dapet 0x7A1B2C3D40)\n"
                    + "3. Cek address itu masuk region libil2cpp.so (GG nunjukin region + base address lib)\n"
                    + "4. Rumus offset:\n"
                    + "```cpp\noffset = address_ketemu - base_libil2cpp\n// contoh: 0x7A1B2C3D40 - 0x7A1B100000 = 0x1C3D40\n```\n"
                    + "5. Kalau region-nya anonymous/heap (bukan libil2cpp), itu field dinamis - pakai *hook field* atau pointer offset dari instance, bukan offset global.";

        if (low.contains("game guardian") || low.contains("gg script") || low.contains("script gg") || low.contains("lua"))
            return "*GAME GUARDIAN - MODDING TANPA C++* \uD83D\uDD0D\n\n"
                    + "GG buat search & edit memory real-time. Contoh *script Lua* auto-search + edit:\n"
                    + "```lua\n-- cari nilai HP lalu edit + freeze\nlocal r = gg.prompt({'HP kamu sekarang:'}, nil, {'number'})\ngg.searchNumber(r[1], gg.TYPE_DWORD)\nlocal res = gg.getResults(10)\nfor i, v in ipairs(res) do\n    v.value = '999999'\n    v.freeze = true -- freeze biar gak turun\nend\ngg.setValues(res)\ngg.addListItems(res)\ngg.toast('HP di-edit & di-freeze!')\n```\n"
                    + "Tips: pakai region *SS/S* (coded app) biar search cepet, dan \"Encrypted region search\" kalau nilai di-encrypt.\n\n"
                    + "Kelemahan GG: gak bisa nge-hook logic (fungsi), cuma edit nilai. Buat hook permanen - mod menu C++.";

        if (low.contains("frida"))
            return "*FRIDA - HOOK REALTIME TANPA REBUILD APK* \uD83D\uDD25\n\n"
                    + "Frida inject JavaScript ke proses game. Cocok buat tes cepet sebelum masukin ke mod menu.\n"
                    + "```javascript\n// hook di Android (pakai frida-il2cpp-bridge)\nconst il2cpp = require('frida-il2cpp-bridge');\nil2cpp.perform(() => {\n    const cls = il2cpp.domain.assembly('Assembly-CSharp').image.class('UserCharacterSkin');\n    const method = cls.method('GiveSkin');\n    method.implementation = function (id) {\n        console.log('GiveSkin dipanggil! id=' + id);\n        return method.invoke(this, 999);\n    };\n});\n```\n"
                    + "Jalanin: *frida -U -f com.target.game -l hook.js* (butuh rooted device / frida-gadget).";

        if (low.contains("python"))
            return "*PYTHON BUAT MODDING* \uD83D\uDC0D\n\n"
                    + "Python paling kepake buat otomasi: parsing dump, extract offset, bikin tool. Contoh *cari offset otomatis dari dump.cs*:\n"
                    + "```python\nimport re\n\ntarget = input('Nama method: ')  # contoh: GiveSkin\nwith open('dump.cs', 'r', encoding='utf-8') as f:\n    for line in f:\n        if target.lower() in line.lower() and 'offset' in line.lower():\n            print(line.strip())\n```\n"
                    + "Hasilnya langsung semua baris yang mengandung nama method + offset-nya - hemat waktu kalau dump.cs gede.\n\n"
                    + "Python juga bisa: bikin script Frida, mass-patch asset, sampai auto-build APK lewat subprocess panggil apktool.";

        if (low.contains("hex") && (low.contains("patch") || low.contains("nop")))
            return "*HEX PATCH - MODIFY BYTE LANGSUNG DI LIB* \uD83D\uDD11\n\n"
                    + "Daripada hook, kadang lebih gampang nimpah byte langsung di libil2cpp.so.\n"
                    + "Contoh pakai KittyMemory di mod menu:\n"
                    + "```cpp\n// arm64: return true langsung\nconst char* patch = \"20 00 80 D2 C0 03 5F D6\";\nuintptr_t addr = KittyMemory::getAbsoluteAddress(\"libil2cpp.so\", 0x1A2B3C);\nKittyMemory::memWrite(addr, patch, strlen(patch)/3 + 1);\n```\n"
                    + "Patch populer (arm64):\n"
                    + "1. *Return true*: 20 00 80 D2 C0 03 5F D6\n"
                    + "2. *Return false / 0*: 00 00 80 D2 C0 03 5F D6\n"
                    + "3. *NOP* (netralin instruksi): 1F 20 03 D5\n\n"
                    + "Sama kayak hook: offset = posisi di lib. Bedanya hex patch gak bisa kondisional (gak bisa toggle) kecuali ditulis ulang saat toggle.";

        if (low.contains("nop"))
            return "*NOP = No Operation* \uD83D\uDC41\uFE0F\n\n"
                    + "NOP = instruksi yang \"gak ngapa-ngapain\". Menimpa instruksi dengan NOP = instruksi asli mati.\n\n"
                    + "Bytes NOP:\n"
                    + "1. arm64 (v8a): *1F 20 03 D5*\n"
                    + "2. arm32 (v7a): *00 F0 20 E3*\n\n"
                    + "Kegunaan: matiin cek anti-cheat, bypass cooldown, dll. Contoh: NOP-in instruksi cek \"uang cukup gak\" sebelum beli - beli selalu lolos.";

        if (low.contains("obfuscate") || low.contains("obfusc"))
            return "*OBFUSCATE - ANTI-SCAN* \uD83D\uDD10\n\n"
                    + "Kenapa nama fitur di mod menu dibungkus *OBFUSCATE(\"...\")*?\n\n"
                    + "Game/anti-cheat bisa scan string di memori & di lib buat nemuin kata kaya \"GodMode\", \"Damage\", \"Speed\". Kalau ketahuan = flag/ban.\n\n"
                    + "OBFUSCATE meng-encrypt string di compile time, baru di-decrypt pas dipakai - jadi string sensitif gak pernah nongol utuh di memori/lib.";

        if (low.contains("speed") && low.contains("hack"))
            return "*SPEED HACK - TIME SCALE* \u26A1\n\n"
                    + "Di Unity, kecepatan game dikontrol *Time.timeScale* (float, default 1.0).\n"
                    + "```cpp\n// hook get_timeScale lalu return nilai custom\nfloat (*old_get_timeScale)(void *instance);\nfloat get_timeScale(void *instance) {\n    if (IsSpeedHack) return SpeedValue; // misal 3.0f\n    return old_get_timeScale(instance);\n}\n```\n"
                    + "Notes:\n"
                    + "1. Nilai gak wajar (100x) bisa bikin physics rusak & gampang dideteksi\n"
                    + "2. Kalau timeScale gak ngaruh, game pakai custom delta - cari \"speed\"/\"velocity\" di engine (contoh: CorgiEngine)";
        if ((low.contains("static") || low.contains("get_instance")) && (low.contains("hook") || low.contains("car")))
            return "*HOOK METHOD STATIC / get_Instance* \uD83D\uDCE6\n\n"
                    + "Method static (contoh: *UserInventory.get_Instance*) dipanggil tanpa instance.\n"
                    + "```cpp\n// hook static: jangan andalkan instance\nIl2CppObject* (*old_get_Instance)(void *method);\nIl2CppObject* get_Instance(void *method) {\n    Il2CppObject* inst = old_get_Instance(method);\n    if (IsAutoMoney && inst != NULL) {\n        // akses field/method lewat inst\n    }\n    return inst;\n}\n```\n"
                    + "Tips: banyak bug \"hook gak work\" terjadi karena method static di-hook pake signature instance biasa.";

        if (low.contains("ida") || low.contains("ghidra"))
            return "*IDA / GHIDRA - TOOL REVERSING* \uD83D\uDD0D\n\n"
                    + "1. Load *libil2cpp.so* (pilih arm64 kalau device 64-bit)\n"
                    + "2. Load *script.json* hasil Il2CppDumper - semua nama fungsi otomatis kelabel\n"
                    + "3. Jump ke offset yang mau dianalisa (misal 0x1D78B10)\n"
                    + "4. Baca assemblynya: lihat apa yang direturn / field mana yang disentuh\n\n"
                    + "Buat apa?\n"
                    + "1. Verifikasi offset sebelum hook (biar gak salah sasaran - crash)\n"
                    + "2. Cari alamat field di instance (offset dari instance)\n"
                    + "3. Belajar struktur fungsi buat hex patch manual\n\n"
                    + "Ghidra gratis & powerful. IDA lebih cepet & enak buat ARM, tapi berbayar.";

        if (low.contains("mshook") || low.contains("dobby") || low.contains("kitty"))
            return "*KITTYMEMORY & LIBRARY HOOK* \u2699\uFE0F\n\n"
                    + "1. *MSHookFunction (Substrate)* - paling umum di mod menu, stabil, butuh lib substrate\n"
                    + "2. *Dobby* - modern, ringan, support arm64 penuh\n"
                    + "3. *KittyMemory* - wrapper nyaman: getAbsoluteAddress + memWrite + hook\n\n"
                    + "```cpp\n// KittyMemory: address absolut dari offset\nuintptr_t addr = KittyMemory::getAbsoluteAddress(\"libil2cpp.so\", 0x1A2B3C);\n```\n"
                    + "Semua hook lib intinya sama: *trampoline* - kopi instruksi asli, arahkan ke hook, sediain jalan balik (old_). Makanya pattern old_{Base} selalu ada di template.";

        return null; // bukan topik ensiklopedia
    }

    // ================= TROUBLESHOOTING =================
    private static String troubleshoot(String msg) {
        String low = msg.toLowerCase();

        if (low.contains("inject") || low.contains("buka") || low.contains("launch"))
            return "*MOD CRASH PAS INJECT/SPLASH* - checklist \uD83D\uDEE1\uFE0F\n\n"
                    + "1. *Offset salah* - paling sering! Cek dump sesuai versi APK, jangan offset versi lama\n"
                    + "2. *Hook jalan terlalu cepat* - tunggu lib ke-load: sleep di hack_thread sampai base libil2cpp.so gak NULL\n"
                    + "3. *Method static vs instance* - signature harus cocok, gak boleh nebak jumlah parameter\n"
                    + "4. *Instance NULL* - tambahin guard *if (instance == NULL) return old_(instance)*\n"
                    + "5. *Anti-cheat* - beberapa game crash pas deteksi lib asing: rename lib + OBFUSCATE semua string\n\n"
                    + "Cara cepet nemuin biang keroknya: matiin SEMUA hook, hidupin satu-satu - yang bikin crash ya itu.";

        if (low.contains("toggle") || low.contains("menu") || low.contains("gak muncul") || low.contains("ga muncul") || low.contains("gak ngefek"))
            return "*MENU/HOOK GAK MUNCUL / GAK NGE-EFEK* - checklist \uD83D\uDEE1\uFE0F\n\n"
                    + "1. *Nomor case gak nyambung* - cek urutan case N di Changes() sama nomor di list menu\n"
                    + "2. *Offset dari versi beda* - re-dump game, offset berubah tiap update\n"
                    + "3. *Hook ke fungsi yang gak kepanggil* - tambahin __android_log_print di hook, kalau log gak pernah muncul = fungsi gak dieksekusi\n"
                    + "4. *Toggle ON tapi fungsi return lebih awal* - baca alurnya di IDA, kadang harus hook fungsi lain\n"
                    + "5. *String menu ke-scan* - pakai OBFUSCATE biar gak dibaca anti-cheat";

        if (low.contains("compile") || low.contains("build") || low.contains("ndk") || low.contains("aide"))
            return "*ERROR COMPILE/NDK/AIDE* - checklist \uD83D\uDEE1\uFE0F\n\n"
                    + "1. *Header il2cpp gak ada* - pastikan folder Includes/ ada di jni + di Android.mk LOCAL_C_INCLUDES\n"
                    + "2. *Undefined reference MSHookFunction* - cek Android.mk: LOCAL_LDLIBS += -lsubstrate (atau lib hook yang dipakai)\n"
                    + "3. *Undefined getAbsoluteAddress* - include KittyMemory.h / Setup.h sesuai template project\n"
                    + "4. *Type conflict* - jangan bikin variabel sama nama sama fungsi (bool GodMode + void GodMode()) - pakai prefix *Is{Base}*\n"
                    + "5. *std::set/map gak kedeteksi* - tambahin #include <set> / #include <map> di atas file\n\n"
                    + "Kalau di AIDE: rebuild 2x (kadang cache), dan pastikan Application.mk APP_ABI sesuai device (arm64-v8a).";

        return "*TROUBLESHOOTING UMUM* \uD83D\uDEE1\uFE0F\n\n"
                + "Ceritain lebih detail biar aku bisa bantu lebih spesifik. Sementara cek dulu:\n"
                + "1. Offset sesuai versi APK yang dipakai?\n"
                + "2. Signature hook cocok (parameter/return type)?\n"
                + "3. Ada guard NULL instance?\n"
                + "4. Logcat bilang apa pas crash? (filter: DEBUG / signal)\n\n"
                + "Contoh tanya spesifik: *\"mod crash pas inject\"*, *\"hook gak ngefek\"*, *\"error compile undefined reference\"*.";
    }

    // ================= HOOK GENERATOR =================
    private static class HookReq {
        String kind; // "ret", "void", "void_no", "update", "field"
        String type;
        String rawName;
        String offset;
        int at;
        int end;
    }

    private static class Off { String val; int start; }

    private static List<HookReq> parseHooks(String msg) {
        List<HookReq> hooks = new ArrayList<>();

        // 1. field hooks: "field <type> <Nama>"
        Matcher fm = FIELD_HOOK.matcher(msg);
        while (fm.find()) {
            HookReq h = new HookReq();
            h.kind = "field";
            h.type = fm.group(1).equalsIgnoreCase("integer") ? "int" : fm.group(1).toLowerCase();
            h.rawName = fm.group(2);
            h.at = fm.start();
            h.end = fm.end();
            hooks.add(h);
        }

        // 2. update hooks: "hook update <Nama>"
        Matcher um = UPDATE_HOOK.matcher(msg);
        while (um.find()) {
            HookReq h = new HookReq();
            h.kind = "update";
            h.rawName = um.group(1);
            h.at = um.start();
            h.end = um.end();
            hooks.add(h);
        }

        // 3. return-type & void: "<type> <Nama>"
        Matcher m = TYPE_NAME.matcher(msg);
        while (m.find()) {
            String t = m.group(1).toLowerCase();
            if (t.equals("integer")) t = "int";
            boolean dup = false;
            for (HookReq h : hooks) {
                if (m.start() >= h.at && m.end() <= h.end) { dup = true; break; }
            }
            if (dup) continue;
            HookReq h = new HookReq();
            h.type = t;
            h.rawName = m.group(2);
            h.at = m.start();
            h.end = m.end();
            if (t.equals("void")) {
                h.kind = NO_UPDATE.matcher(msg).find() ? "void_no" : "void";
            } else {
                h.kind = "ret";
            }
            hooks.add(h);
        }

        // urut sesuai posisi di pesan
        Collections.sort(hooks, new Comparator<HookReq>() {
            @Override
            public int compare(HookReq a, HookReq b) { return a.at - b.at; }
        });

        // 4. assign offset by POSISI: offset pertama yang muncul
        //    SETELAH posisi hook, dan belum dipakai hook lain
        List<Off> offs = new ArrayList<>();
        Matcher om = OFFSET.matcher(msg);
        while (om.find()) {
            Off o = new Off();
            o.val = om.group();
            o.start = om.start();
            offs.add(o);
        }
        for (HookReq h : hooks) {
            h.offset = "0x0";
            for (Off o : offs) {
                if (o.start > h.at && o.val != null) {
                    h.offset = o.val;
                    o.val = null; // tandai sudah dipakai
                    break;
                }
            }
        }
        return hooks;
    }

    private static String hookAnswer(HookReq h, int num) {
        String base = sanitizeName(h.rawName, h.type == null ? "void" : h.type);

        if (h.kind.equals("field"))
            return "Siap bro! *Hook Field " + base + "* (" + h.type + ") offset " + h.offset + " \uD83D\uDD25\n"
                    + "*FIELD PATCH* - tulis nilai langsung ke address (tanpa hook function).\n\n```cpp\n"
                    + tplField(h.type, base, h.offset, num) + "\n```";

        if (h.kind.equals("update"))
            return "Siap bro! *Hook Update " + base + "* offset " + h.offset + " \uD83D\uDD25\n"
                    + "*WITH UPDATE* - fungsi asli tetap dipanggil, hook siap ditambahi logic ekstra.\n\n```cpp\n"
                    + tplUpdate(base, h.offset, num) + "\n```";

        if (h.kind.equals("void_no"))
            return "Siap bro! *Hook Void " + base + " (tanpa update)* offset " + h.offset + " \uD83D\uDD25\n"
                    + "*WITHOUT UPDATE* - fungsi asli gak pernah dipanggil, method dimatiikan total saat ON.\n\n```cpp\n"
                    + tplVoidNoUpdate(base, h.offset, num) + "\n```";

        if (h.kind.equals("void"))
            return "Siap bro! *Hook Void " + base + "* offset " + h.offset + " \uD83D\uDD25\n"
                    + "*VOID HOOK* - toggle ON = fungsi di-skip, OFF = jalan normal.\n\n```cpp\n"
                    + tplVoid(base, h.offset, num) + "\n```";

        if (h.type.equals("string"))
            return "Siap bro! *Hook " + base + "* (string) offset " + h.offset + " \uD83D\uDD25\n\n```cpp\n"
                    + tplString(base, h.offset, num) + "\n```";

        return "Siap bro! *Hook " + base + "* (" + h.type + ") offset " + h.offset + " \uD83D\uDD25\n\n```cpp\n"
                + tplRet(h.type, base, h.offset, num) + "\n```";
    }

    /** nomor menu otomatis dari hook yang sudah pernah di-generate di riwayat */
    private static int startNumber(List<Msg> history) {
        int max = 0;
        if (history == null) return max + 1;
        for (Msg m : history) {
            if (!"bot".equals(m.role)) continue;
            Matcher cm = CASE_NUM.matcher(m.content);
            while (cm.find()) {
                int n = Integer.parseInt(cm.group(1));
                if (n > max) max = n;
            }
        }
        return max + 1;
    }

    /** bersihkan nama jadi {Base}: huruf/angka/_ saja, kapital depan, bool tanpa "Is" */
    private static String sanitizeName(String name, String type) {
        String n = name == null ? "" : name.replaceAll("[^A-Za-z0-9_]", "");
        if (n.isEmpty()) n = "Contoh";
        if (type.equals("bool") && n.length() > 2 && n.substring(0, 2).equalsIgnoreCase("Is"))
            n = n.substring(2);
        if (type.equals("bool") && n.equalsIgnoreCase("Is")) n = "Contoh";
        return n.substring(0, 1).toUpperCase() + (n.length() > 1 ? n.substring(1) : "");
    }

    private static String head(String isb) { return "bool " + isb + " = false;\n\n"; }

    // ---------- TEMPLATE: RETURN-TYPE ----------
    private static String tplRet(String type, String base, String offset, int num) {
        String isb = "Is" + base;
        String retTrue;
        if (type.equals("bool")) retTrue = "true";
        else if (type.equals("int")) retTrue = "999999";
        else if (type.equals("float")) retTrue = "999.0f";
        else retTrue = "999.0";

        return head(isb)
                + type + " (*old_" + base + ")(void *instance);\n"
                + type + " " + base + "(void *instance) {\n"
                + "    if (instance != NULL && " + isb + ") {\n"
                + "        return " + retTrue + ";\n"
                + "    }\n"
                + "    return old_" + base + "(instance);\n"
                + "}\n\n"
                + "OBFUSCATE(\"" + num + "_Toggle_Use" + base + "\"),\n\n"
                + "MSHookFunction((void *)getAbsoluteAddress(\"libil2cpp.so\", " + offset + "), "
                + "(void *) " + base + ", (void **) &old_" + base + ");\n\n"
                + "case " + num + ":\n"
                + "    " + isb + " = boolean;\n"
                + "    break;";
    }

    // ---------- TEMPLATE: STRING ----------
    private static String tplString(String base, String offset, int num) {
        String isb = "Is" + base;
        return head(isb)
                + "Il2CppString* (*old_" + base + ")(void *instance);\n"
                + "Il2CppString* " + base + "(void *instance) {\n"
                + "    if (instance != NULL && " + isb + ") {\n"
                + "        // return il2cpp_string_new(\"teks custom\"); // aktifin kalau mau ganti teks\n"
                + "    }\n"
                + "    return old_" + base + "(instance);\n"
                + "}\n\n"
                + "OBFUSCATE(\"" + num + "_Toggle_Use" + base + "\"),\n\n"
                + "MSHookFunction((void *)getAbsoluteAddress(\"libil2cpp.so\", " + offset + "), "
                + "(void *) " + base + ", (void **) &old_" + base + ");\n\n"
                + "case " + num + ":\n"
                + "    " + isb + " = boolean;\n"
                + "    break;";
    }

    // ---------- TEMPLATE: VOID (skip saat ON) ----------
    private static String tplVoid(String base, String offset, int num) {
        String isb = "Is" + base;
        return head(isb)
                + "void (*old_" + base + ")(void *instance);\n"
                + "void " + base + "(void *instance) {\n"
                + "    if (instance != NULL && " + isb + ") {\n"
                + "        return; // toggle ON = fungsi di-skip\n"
                + "    }\n"
                + "    old_" + base + "(instance);\n"
                + "}\n\n"
                + "OBFUSCATE(\"" + num + "_Toggle_Disable" + base + "\"),\n\n"
                + "MSHookFunction((void *)getAbsoluteAddress(\"libil2cpp.so\", " + offset + "), "
                + "(void *) " + base + ", (void **) &old_" + base + ");\n\n"
                + "case " + num + ":\n"
                + "    " + isb + " = boolean;\n"
                + "    break;";
    }

    // ---------- TEMPLATE: VOID TANPA UPDATE ----------
    private static String tplVoidNoUpdate(String base, String offset, int num) {
        String isb = "Is" + base;
        return head(isb)
                + "// TANPA UPDATE: old_" + base + " gak pernah dipanggil,\n"
                + "// method asli dimatiikan total saat toggle ON\n"
                + "void " + base + "(void *instance) {\n"
                + "    if (instance == NULL || " + isb + ") {\n"
                + "        return; // skip penuh - tanpa old_ call\n"
                + "    }\n"
                + "    // catatan: hook tanpa update gak punya jalan balik\n"
                + "    // ke fungsi asli saat OFF (pakai NOP/patch kalau perlu)\n"
                + "}\n\n"
                + "OBFUSCATE(\"" + num + "_Toggle_Kill" + base + "\"),\n\n"
                + "MSHookFunction((void *)getAbsoluteAddress(\"libil2cpp.so\", " + offset + "), "
                + "(void *) " + base + ", NULL);\n\n"
                + "case " + num + ":\n"
                + "    " + isb + " = boolean;\n"
                + "    break;";
    }

    // ---------- TEMPLATE: UPDATE HOOK ----------
    private static String tplUpdate(String base, String offset, int num) {
        String isb = "Is" + base;
        return head(isb)
                + "// WITH UPDATE: fungsi asli tetap dipanggil dulu,\n"
                + "// baru hook-nya bisa nambahin logic ekstra saat ON\n"
                + "void (*old_" + base + ")(void *instance);\n"
                + "void " + base + "(void *instance) {\n"
                + "    old_" + base + "(instance); // update asli selalu jalan\n"
                + "    if (instance != NULL && " + isb + ") {\n"
                + "        // === logic ekstra lu di sini ===\n"
                + "        // contoh: *(int*)((uintptr_t)instance + 0x18) = 999999;\n"
                + "    }\n"
                + "}\n\n"
                + "OBFUSCATE(\"" + num + "_Toggle_Mod" + base + "\"),\n\n"
                + "MSHookFunction((void *)getAbsoluteAddress(\"libil2cpp.so\", " + offset + "), "
                + "(void *) " + base + ", (void **) &old_" + base + ");\n\n"
                + "case " + num + ":\n"
                + "    " + isb + " = boolean;\n"
                + "    break;";
    }

    // ---------- TEMPLATE: FIELD PATCH ----------
    private static String tplField(String type, String base, String offset, int num) {
        String isb = "Is" + base;
        String val;
        if (type.equals("bool")) val = "true";
        else if (type.equals("int") || type.equals("long")) val = "999999";
        else if (type.equals("float")) val = "999.0f";
        else if (type.equals("double")) val = "999.0";
        else if (type.equals("byte")) val = "255";
        else val = "0";

        return head(isb)
                + "// FIELD PATCH: tulis nilai langsung ke address (bukan hook method)\n"
                + type + " " + base + "_Val = " + val + "; // nilai yang dipaksa\n\n"
                + "void Patch" + base + "() {\n"
                + "    uintptr_t addr = (uintptr_t)getAbsoluteAddress(\"libil2cpp.so\", " + offset + ");\n"
                + "    if (addr != 0) {\n"
                + "        *(" + type + "*)addr = " + base + "_Val;\n"
                + "    }\n"
                + "}\n\n"
                + "OBFUSCATE(\"" + num + "_Toggle_Field" + base + "\"),\n\n"
                + "// panggil saat toggle ON (di Changes) atau tiap frame kalau nilai di-reset game\n"
                + "case " + num + ":\n"
                + "    " + isb + " = boolean;\n"
                + "    if (boolean) Patch" + base + "();\n"
                + "    break;";
    }
}
