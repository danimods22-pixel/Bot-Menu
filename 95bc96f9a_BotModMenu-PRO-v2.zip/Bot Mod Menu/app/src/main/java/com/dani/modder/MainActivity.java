package com.dani.modder;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * MainActivity - layar chat utama BOT MOD MENU PRO.
 * Efek "memproses..." biar bot gak bales instan (kayak ngetik beneran).
 * Tanpa androidx / library luar, murni framework Android (AIDE friendly).
 */
public class MainActivity extends Activity {

    public static final int REQUEST_HISTORY = 1;
    /** database share ke HistoryActivity */
    public static ChatDatabase DB;

    private static final Pattern CODE_BLOCK = Pattern.compile("```[a-zA-Z]*\\n([\\s\\S]*?)\\n```");

    private ScrollView scroll;
    private LinearLayout chatList;
    private EditText input;
    private Button btnSend;
    private ChatDatabase.Conv cur;

    private final Handler main = new Handler(Looper.getMainLooper());
    private boolean processing = false;

    // typing indicator
    private LinearLayout typingRow;
    private TextView typingText;
    private int dotsStage = 0;
    private final Runnable dotsRunnable = new Runnable() {
        @Override
        public void run() {
            if (typingText == null) return;
            dotsStage = (dotsStage + 1) % 4;
            String s = "memproses";
            for (int i = 0; i < dotsStage; i++) s += ".";
            typingText.setText(s);
            main.postDelayed(this, 350);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (DB == null) DB = new ChatDatabase(this);

        scroll = (ScrollView) findViewById(R.id.scroll);
        chatList = (LinearLayout) findViewById(R.id.chatList);
        input = (EditText) findViewById(R.id.input);
        btnSend = (Button) findViewById(R.id.btnSend);

        // ===== input =====
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { onSend(); }
        });
        input.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEND) { onSend(); return true; }
                return false;
            }
        });

        // ===== chips: klik = langsung kirim =====
        int[] chipIds = {R.id.chip1, R.id.chip2, R.id.chip3};
        for (int id : chipIds) {
            TextView chip = (TextView) findViewById(id);
            final String t = chip.getText().toString();
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    input.setText(t);
                    onSend();
                }
            });
        }

        // ===== riwayat =====
        TextView btnHistory = (TextView) findViewById(R.id.btnHistory);
        btnHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(MainActivity.this, HistoryActivity.class);
                startActivityForResult(it, REQUEST_HISTORY);
            }
        });

        // ===== chat =====
        cur = DB.lastOrCreate();
        renderAll();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_HISTORY || data == null) return;
        String id = data.getStringExtra("id");
        if ("__new__".equals(id)) {
            cur = DB.newConversation();
        } else {
            ChatDatabase.Conv c = DB.get(id);
            if (c != null) cur = c;
        }
        renderAll();
    }

    // ================= CHAT =================

    private void onSend() {
        final String text = input.getText().toString().trim();
        if (text.isEmpty() || cur == null || processing) return;

        processing = true;
        btnSend.setEnabled(false);

        List<BotBrain.Msg> history = DB.historyOf(cur);
        final String reply = BotBrain.reply(text, history);

        DB.addMessage(cur, "user", text);
        addMessageView("user", text);

        showTyping();
        scrollDown();

        // delay realistis: panjang jawaban = lama "ngetik"-nya
        long delay = 800 + Math.min(2200, reply.length() * 3L);
        main.postDelayed(new Runnable() {
            @Override
            public void run() {
                hideTyping();
                DB.addMessage(cur, "bot", reply);
                addMessageView("bot", reply);
                processing = false;
                btnSend.setEnabled(true);
                scrollDown();
            }
        }, delay);

        input.setText("");
    }

    private void scrollDown() {
        scroll.post(new Runnable() {
            @Override
            public void run() { scroll.fullScroll(View.FOCUS_DOWN); }
        });
    }

    // ================= TYPING INDICATOR =================

    private void showTyping() {
        typingRow = new LinearLayout(this);
        typingRow.setOrientation(LinearLayout.HORIZONTAL);
        typingRow.setGravity(Gravity.START);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowLp.bottomMargin = dp(12);
        typingRow.setLayoutParams(rowLp);

        LinearLayout bubble = new LinearLayout(this);
        bubble.setOrientation(LinearLayout.VERTICAL);
        bubble.setBackgroundResource(R.drawable.bg_bot);
        bubble.setPadding(dp(13), dp(11), dp(13), dp(11));

        typingText = new TextView(this);
        typingText.setText("memproses");
        typingText.setTextColor(0xFF9E9E9E);
        typingText.setTextSize(14f);
        typingText.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.ITALIC));
        bubble.addView(typingText);

        typingRow.addView(bubble);
        chatList.addView(typingRow);
        dotsStage = 0;
        main.postDelayed(dotsRunnable, 350);
    }

    private void hideTyping() {
        main.removeCallbacks(dotsRunnable);
        if (typingRow != null) chatList.removeView(typingRow);
        typingRow = null;
        typingText = null;
    }

    // ================= RENDER =================

    private void renderAll() {
        chatList.removeAllViews();
        if (cur == null) return;
        for (ChatDatabase.Msg m : cur.messages) addMessageView(m.role, m.content);
        scrollDown();
    }

    private void addMessageView(String role, String content) {
        boolean user = "user".equals(role);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(user ? Gravity.END : Gravity.START);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowLp.bottomMargin = dp(12);
        row.setLayoutParams(rowLp);

        LinearLayout bubble = new LinearLayout(this);
        bubble.setOrientation(LinearLayout.VERTICAL);
        bubble.setBackgroundResource(user ? R.drawable.bg_user : R.drawable.bg_bot);
        bubble.setPadding(dp(13), dp(11), dp(13), dp(11));
        LinearLayout.LayoutParams bbLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bubble.setLayoutParams(bbLp);

        if (user) {
            TextView tv = new TextView(this);
            tv.setText(content);
            tv.setTextColor(0xFFFFFFFF);
            tv.setTextSize(14f);
            tv.setMaxWidth(dp(280));
            bubble.addView(tv);
        } else {
            addBotContent(bubble, content);
        }

        row.addView(bubble);
        chatList.addView(row);
    }

    /** isi bubble bot: teks biasa + ```...``` jadi code block dengan tombol Copy */
    private void addBotContent(LinearLayout bubble, String content) {
        Matcher m = CODE_BLOCK.matcher(content);
        int last = 0;
        while (m.find()) {
            String before = content.substring(last, m.start());
            if (!before.trim().isEmpty()) addText(bubble, before.trim());
            addCodeBlock(bubble, m.group(1));
            last = m.end();
        }
        String rest = content.substring(last);
        if (!rest.trim().isEmpty()) addText(bubble, rest.trim());
    }

    private void addText(LinearLayout bubble, String text) {
        TextView tv = new TextView(this);
        tv.setText(styled(text));
        tv.setTextColor(0xFFEAEAEA);
        tv.setTextSize(14f);
        tv.setMaxWidth(dp(300));
        bubble.addView(tv);
        LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) tv.getLayoutParams();
        lp.bottomMargin = dp(6);
        tv.setLayoutParams(lp);
    }

    private void addCodeBlock(LinearLayout bubble, String code) {
        final String raw = code;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundResource(R.drawable.bg_code);
        box.setPadding(dp(10), dp(8), dp(10), dp(10));
        LinearLayout.LayoutParams boxLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        boxLp.bottomMargin = dp(6);
        box.setLayoutParams(boxLp);

        // header kecil
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        box.addView(head);

        TextView label = new TextView(this);
        label.setText("code");
        label.setTextColor(0xFF00E5FF);
        label.setTextSize(10f);
        label.setTypeface(Typeface.MONOSPACE);
        LinearLayout.LayoutParams labelLp = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        label.setLayoutParams(labelLp);
        head.addView(label);

        Button copy = new Button(this);
        copy.setText("Copy");
        copy.setTextColor(0xFF00E5FF);
        copy.setTextSize(10f);
        copy.setAllCaps(false);
        copy.setPadding(dp(10), dp(2), dp(10), dp(2));
        copy.setBackgroundResource(android.R.color.transparent);
        copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { copyText(raw); }
        });
        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        copyLp.height = dp(26);
        copy.setLayoutParams(copyLp);
        head.addView(copy);

        // kode
        TextView codeTv = new TextView(this);
        codeTv.setText(raw);
        codeTv.setTextColor(0xFFC8E6FF);
        codeTv.setTextSize(12f);
        codeTv.setTypeface(Typeface.MONOSPACE);
        codeTv.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) { copyText(raw); return true; }
        });
        box.addView(codeTv);

        bubble.addView(box);
    }

    private void copyText(String code) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("code", code));
        Toast.makeText(this, "Kode dicopy \uD83D\uDC4D", Toast.LENGTH_SHORT).show();
    }

    /** *teks* jadi bold cyan, sisanya biasa */
    private CharSequence styled(String s) {
        SpannableStringBuilder b = new SpannableStringBuilder();
        String rest = s;
        int i;
        while ((i = rest.indexOf('*')) >= 0) {
            int j = rest.indexOf('*', i + 1);
            if (j < 0) { b.append(rest); break; }
            b.append(rest.substring(0, i));
            int start = b.length();
            b.append(rest.substring(i + 1, j));
            b.setSpan(new StyleSpan(Typeface.BOLD), start, b.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            b.setSpan(new ForegroundColorSpan(0xFF00E5FF), start, b.length(), 0);
            rest = rest.substring(j + 1);
        }
        b.append(rest);
        return b;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
