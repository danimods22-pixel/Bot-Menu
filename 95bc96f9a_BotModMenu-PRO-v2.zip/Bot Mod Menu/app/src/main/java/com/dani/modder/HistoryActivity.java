package com.dani.modder;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * HistoryActivity — riwayat percakapan (sidebar versi AIDE friendly).
 * Klik = buka percakapan, tekan lama = hapus.
 */
public class HistoryActivity extends Activity {

    private ListView list;
    private Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        list = (ListView) findViewById(R.id.historyList);
        adapter = new Adapter();
        list.setAdapter(adapter);

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { finish(); }
        });

        findViewById(R.id.btnNewChat).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent();
                it.putExtra("id", "__new__");
                setResult(RESULT_OK, it);
                finish();
            }
        });

        list.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(android.widget.AdapterView<?> parent, View view, int position, long id) {
                Intent it = new Intent();
                it.putExtra("id", MainActivity.DB.list().get(position).id);
                setResult(RESULT_OK, it);
                finish();
            }
        });

        list.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(android.widget.AdapterView<?> parent, View view, final int position, long id) {
                final ChatDatabase.Conv c = MainActivity.DB.list().get(position);
                new AlertDialog.Builder(HistoryActivity.this)
                        .setTitle("Hapus percakapan")
                        .setMessage("Hapus \"" + c.title + "\"?")
                        .setPositiveButton("Hapus", new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface dialog, int which) {
                                MainActivity.DB.delete(c.id);
                                adapter.notifyDataSetChanged();
                            }
                        })
                        .setNegativeButton("Batal", null)
                        .show();
                return true;
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        adapter.notifyDataSetChanged();
    }

    private class Adapter extends BaseAdapter {

        @Override
        public int getCount() { return MainActivity.DB.list().size(); }

        @Override
        public Object getItem(int position) { return MainActivity.DB.list().get(position); }

        @Override
        public long getItemId(int position) { return position; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ChatDatabase.Conv c = MainActivity.DB.list().get(position);

            LinearLayout item = new LinearLayout(HistoryActivity.this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setPadding(dp(16), dp(12), dp(16), dp(12));
            item.setBackgroundResource(android.R.color.transparent);

            TextView title = new TextView(HistoryActivity.this);
            title.setText(c.title);
            title.setTextColor(0xFFEAEAEA);
            title.setTextSize(14f);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setSingleLine(true);
            item.addView(title);

            TextView sub = new TextView(HistoryActivity.this);
            String date = new SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(new Date(c.updated));
            sub.setText(date + "  •  " + c.messages.size() + " pesan");
            sub.setTextColor(0xFF9E9E9E);
            sub.setTextSize(11f);
            item.addView(sub);

            // garis pemisah halus
            View line = new View(HistoryActivity.this);
            line.setBackgroundColor(Color.parseColor("#222230"));
            LinearLayout.LayoutParams lineLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
            lineLp.topMargin = dp(12);
            line.setLayoutParams(lineLp);
            item.addView(line);

            return item;
        }

        private int dp(float v) {
            return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
        }
    }
}
